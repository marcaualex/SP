package SPlab;

public class Image {
	String imgName;
	
	Image(String imgName){
		this.imgName=imgName;
	}
}
