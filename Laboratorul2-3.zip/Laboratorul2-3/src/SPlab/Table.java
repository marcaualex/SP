package SPlab;

public class Table {
	String tableName;
	
	Table(String tableName){
		this.tableName=tableName;
	}
}
