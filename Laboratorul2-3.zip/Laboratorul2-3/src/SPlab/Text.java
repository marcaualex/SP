package SPlab;

public class Text {
	String text;
	
	Text(String text){
		this.text=text;
	}
}
