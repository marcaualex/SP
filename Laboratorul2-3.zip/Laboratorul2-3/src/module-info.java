/**
 * 
 */
/**
 * @author Marcau
 *
 */
module labolatorul2 {
	
}