package SPlab;

public class DeleteCommand implements Command {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}
	public void unexecute() {
		
	}

}
