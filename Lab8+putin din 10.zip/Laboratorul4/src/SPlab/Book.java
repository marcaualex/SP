package SPlab;

import java.util.ArrayList;

public class Book implements Element {
	  private Author author;
	  private ArrayList<Element> content = new ArrayList<Element>();
	  private String name;

	  public String getName() {
	    return name;
	  }

	  public void setName(String name) {
	    this.name = name;
	  }

	  public Book(String name) {
	    this.name = name;
	  }

	  
	  public void add(Element element) {
	    this.content.add(element);
	  }

	  
	  public void remove(Element element) {
	    this.content.remove(element);
	  }

	  
	  public int getChild(Element element) {
	    return this.content.indexOf(element);
	  }

	  
	  public void print() {
		  System.out.println(name);
	    for (Element element : content) {
	        

	    	element.print();
	    }
	  }


	  public Author getAuthor() {
	    return author;
	  }


	  public void setAuthor(Author author) {
	    this.author = author;
	  }

	@Override
	public void accept(Visitor vis) {
		
		for(Element e:this.content)
			e.accept(vis);
		
	}
	}
