package SPlab;

public class DocumentManager {
	  private static DocumentManager sharedInstance = null;
	  private static Element book = null;

	  private DocumentManager() {

	  }

	  public static DocumentManager getInstance() {
	    if (sharedInstance == null) {
	      sharedInstance = new DocumentManager();
	    }
	    return sharedInstance;
	  }

	  public void setBook(Element book) {
	    DocumentManager.book = book;
	  }

	  public static Element getBook() {
	    return book;
	  }
	}
