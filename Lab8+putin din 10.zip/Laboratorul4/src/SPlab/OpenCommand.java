package SPlab;

public class OpenCommand implements Command {
	String cmd;
	OpenCommand(String cmd){
		this.cmd=cmd;
	}

  @Override
  public void execute() {
    JSONBuilder jsonBuilder = new JSONBuilder(cmd);
    jsonBuilder.build();
    Book book = new Book("carte1");
    book.add(jsonBuilder.getResult());
    DocumentManager.getInstance().setBook(book);
    book.print();
  }

}