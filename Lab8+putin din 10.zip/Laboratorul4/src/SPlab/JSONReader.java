package SPlab;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONReader {
	public static void main(final String[] args) throws JsonParseException, JsonMappingException, IOException {

	    final ObjectMapper mapper = new ObjectMapper();
	    @SuppressWarnings("unchecked")
		final HashMap<String, Object> readValue = mapper.readValue(new File("book.json"), HashMap.class);
	    for (Object value : readValue.values()) {
	      System.out.println("value = " + value);
	    }
	    System.out.println("read value = " + readValue);
	}
}
