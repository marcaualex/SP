package SPlab;

public class UndoCommand implements Command {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}
	public void unexecute() {
		
	}

}
