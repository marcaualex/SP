package SPlab;

public interface Command {
	public void execute();
}
