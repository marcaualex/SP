package SPlab;

public class StatisticsCommand implements Command{

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}
	
}
