package SPlab;

public interface AlignStrategy {
	public void print();
}
