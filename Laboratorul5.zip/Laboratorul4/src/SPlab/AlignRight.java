package SPlab;

public class AlignRight implements AlignStrategy{
	public  void print() {
	System.out.println("											Align Right");
	}
}
