package SPlab;

public class AlignCenter implements AlignStrategy{
	public void print() {
		System.out.println("							Align Center");
	}

}
