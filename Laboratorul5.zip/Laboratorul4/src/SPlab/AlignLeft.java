package SPlab;

public class AlignLeft implements AlignStrategy{
	public void print() {
		System.out.println("	Align Left");
	}
}
