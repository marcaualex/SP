package SPlab;

import java.util.ArrayList;

public class Table implements Element {
	String tableName;
	
	public void add(Element elem) {
	}
	public void remove(Element elem) {
	}
	public int getChild(Element elem) {
		return 0;
	}
	public void print() {
		System.out.println("--TableName--");
		System.out.println(tableName);
	}
}
