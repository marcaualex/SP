package SPlab;

public class Author {
	String name;
	
	Author(String name){
		this.name=name;
	}
}
